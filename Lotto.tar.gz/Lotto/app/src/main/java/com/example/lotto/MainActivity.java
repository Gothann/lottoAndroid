package com.example.lotto;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText input;
    Button button;
    TextView output;
    ArrayList<Integer> generatedNumbers;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.input);
        button = findViewById(R.id.button);
        output = findViewById(R.id.output);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userInput=getUserInput();
                ArrayList<Integer> userNumbers=convertToNumberList(userInput);
                generatedNumbers=generateNumbers();
                displayNumbers(generatedNumbers);
                int result=checkResult(userNumbers,generatedNumbers);

               int MAX_LENGTH=6;
               input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(MAX_LENGTH)});

               
            }

        });


    }
    public String getUserInput(){
//            String text=String.valueOf(input.getText());

        return input.getText().toString();
    }
    public ArrayList<Integer> convertToNumberList(String userInput){
        ArrayList<Integer> numberList=new ArrayList<>();
        for (int i=0;i<userInput.length();i++){
            char c= userInput.charAt(i);
            if(Character.isDigit(c)){
                int number=Character.getNumericValue(c);
                numberList.add(number);

            }
        } return numberList;
    }

    public ArrayList<Integer> generateNumbers(){

        ArrayList<Integer> numbersList= new ArrayList<>();
        Random random=new Random();
        for(int i=0;i<6;i++){
            int number=random.nextInt(49) +1;
            numbersList.add(number);
        }
        return numbersList;
    }

    int checkResult(ArrayList<Integer> userNumbers,ArrayList<Integer> generatedNumbers){
        int count=0;
        for(Integer number: userNumbers){
            if(generatedNumbers.contains(number)){count++;}
        }return count;
    }
    public void displayNumbers(ArrayList<Integer> numberslist){
    StringBuilder stringBuilder=new StringBuilder();
    for(Integer number:numberslist){
        stringBuilder.append(number).append(",");
    }
    output.setText(stringBuilder.toString());

    }
}